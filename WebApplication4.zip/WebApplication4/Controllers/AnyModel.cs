﻿namespace WebApplication4.Controllers
{
    public class AnyModel
    {
        public int MyProperty { get; set; }

        public string FilesToBeUploaded { get; set; }
    }
}